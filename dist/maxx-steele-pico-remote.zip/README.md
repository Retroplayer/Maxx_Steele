# Maxx Steele reverse engineering

Firmware and peripheral research for the 1984 Ideal/CBS Toys robot.

- [Pico USB remote emulator: installation and usage](pico/README.md)
- [ROM- and capture-verified remote protocol](docs/remote-protocol.md)
- [Memory map](docs/memory-map.md)
- [Fixed-layout cartridge format](docs/cartridge-builder-format.md)
- [Original demo cartridge](docs/demo-cartridge.md)

The Pico implementation uses MicroPython PIO for precise waveform generation
and a USB CDC text-command interface. A Windows-compatible Python console is
provided in `pc/remote_cli.py`. Host tests validate generated waveforms against
the original robot ROM. Physical Pico operation and the transmitter-jack
electrical interface still require measurement and testing.

Original uploaded ROM images and captures are kept outside the checkout in
the workspace attachments; the tools accept their paths and verify the mapped
ROM's hash. No cartridge template has been modified.
